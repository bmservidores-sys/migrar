<?php
/**********************
	-> Migrador
	-> Litlle - juniospok2@hotmail.com
	-> Versão 2.1
**********************/
//-- Configuração gerais tanto pra IMPORTAÇÃO quanto pra EXPORTAÇÃO
define('SITE_HOST','localhost'); // Host do servidor Mssql [ Padrão => localhost ]
define('SITE_USER','sa'); // Usuário do servidor Mssql [ Padrão => sa ]
define('SITE_PASS','123456'); // Senha do servidor Mssql

define('NOVA_VERSAO',false); // VERSÕES NOVAS = TRUE  /  VERSÔES  VELHAS = FALSE

$BONUS['MIGRA'] = array("ATIVA" => true, "GOLD" => 100,"NAME_GOLD" => "Gold", "VIP_TYPE" => 1, "VIP_DAYS" => 15,"NAME_VIP" => "Vip Silver");

define('MIGRAR_VIP', true);
define('MIGRAR_GOLD', true);

define('MULTIPLOS_BAU',false);
$MULTIPLOS['bau'] = array('TABLE' => 'ExtWarehouse',
						  'COLUMN_LOGIN' => 'VaultID');

$LITLLE['CLASS'] = array(
						 0 => 'Dark Wizard',
						 1 => 'Soul Master',
						 2 => 'Grand Master',
						 16 => 'Dark Knight',
						 17 => 'Blade Knight',
						 18 => 'Blade Master',
						 32 => 'Fary Elf',
						 33 => 'Muse Elf',
						 34 => 'Hight Elf',
						 48 => 'Magic Gladiator',
						 49 => 'Duel Master',
						 64 => 'Dark Lord',
						 65 => 'Lord Emporer',
						 80 => 'Summoner',
						 81 => 'Blood Summoner',
						 82 => 'Dimension Master'
						 );


//-- Configuração sevidor IMPORTADOR
define('IMP_NAME','Mu Recebe'); # Nome do Servidor
define('IMP_DB','MuOnline2'); // Data Base do servidor Mssql [ Padrão => MuOnline ]

define('IMP_COLUMN_RESET','resets'); # Coluna onde armazena os resets na Character
$TABLE['IMP_VIP'] = array("TABLE" => "MEMB_INFO","COLUMN_TYPE" => "vip", "COLUMN_DAYS" => "creditos", "COLUMN_LOGIN" => "memb___id");
$TABLE['IMP_GOLD'] = array("TABLE" => "MEMB_INFO", "COLUMN_GOLDS" => "golds", "COLUMN_LOGIN" => "memb___id");

//-- Configuração sevidor EXPORTADOR
define('EXP_NAME','Mu Envia'); # Nome do Servidor
define('EXP_DB','MuOnline3'); // Data Base do servidor Mssql [ Padrão => MuOnline2 ]

define('EXP_COLUMN_RESET','resets'); # Coluna onde armazena os resets na Character
$TABLE['EXP_VIP'] = array("TABLE" => "MEMB_INFO","COLUMN_TYPE" => "vip", "COLUMN_DAYS" => "creditos", "COLUMN_LOGIN" => "memb___id");
$TABLE['EXP_GOLD'] = array("TABLE" => "MEMB_INFO", "COLUMN_GOLDS" => "gold", "COLUMN_LOGIN" => "memb___id");






?>